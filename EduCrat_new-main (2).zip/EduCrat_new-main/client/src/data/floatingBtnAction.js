const actions = [
    { label: "About", icon: "😁", onClick: console.log },
    { label: "Profile", icon: "👩‍🏫", onClick: console.log },
    { label: "Picture", icon: "📸", onClick: console.log },
    { label: "Trash", icon: "🚮", onClick: console.log },
  ];

  export default actions;