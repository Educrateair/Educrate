import React from 'react'

const StudentProfile = () => {
  return (
    <div>StudentProfile</div>
  )
}

export default StudentProfile